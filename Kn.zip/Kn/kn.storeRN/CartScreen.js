import React, { useState, useEffect } from 'react';
import { View, StyleSheet, FlatList, Text, TouchableOpacity, Image, ScrollView } from 'react-native';

const CartScreen = ({ navigation }) => {
  const [cartItems, setCartItems] = useState([]);

  useEffect(() => {
    // Load cart items from storage
    const loadCart = async () => {
      // Implement your cart loading logic here
      // For now, we'll use mock data
      setCartItems([
        { id: '1', name: 'Auto Clean', price: 111.80, quantity: 1, image: require('../assets/auto_clean_ultra_limpador_5l_magil_clean_777_1_9fcf12146b390c64322510e865fce252.webp') },
        // Add other items as needed
      ]);
    };
    loadCart();
  }, []);

  const updateQuantity = (index, delta) => {
    const newItems = [...cartItems];
    newItems[index].quantity += delta;
    
    if (newItems[index].quantity <= 0) {
      newItems.splice(index, 1);
    }
    
    setCartItems(newItems);
    // Save to storage
  };

  const removeItem = (index) => {
    const newItems = [...cartItems];
    newItems.splice(index, 1);
    setCartItems(newItems);
    // Save to storage
  };

  const calculateTotal = () => {
    return cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const renderItem = ({ item, index }) => (
    <View style={styles.cartItem}>
      <Image source={item.image} style={styles.itemImage} />
      <View style={styles.itemDetails}>
        <Text style={styles.itemName}>{item.name}</Text>
        <Text style={styles.itemPrice}>Preço: R$ {item.price.toFixed(2)}</Text>
        <View style={styles.quantityContainer}>
          <TouchableOpacity 
            style={styles.quantityButton}
            onPress={() => updateQuantity(index, -1)}
          >
            <Text style={styles.quantityButtonText}>-</Text>
          </TouchableOpacity>
          <Text style={styles.quantityText}>{item.quantity}</Text>
          <TouchableOpacity 
            style={styles.quantityButton}
            onPress={() => updateQuantity(index, 1)}
          >
            <Text style={styles.quantityButtonText}>+</Text>
          </TouchableOpacity>
        </View>
        <TouchableOpacity 
          style={styles.removeButton}
          onPress={() => removeItem(index)}
        >
          <Text style={styles.removeButtonText}>Remover</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Image 
          source={require('../assets/1.png')} 
          style={styles.logo}
        />
        <Text style={styles.headerTitle}>KN.STORE</Text>
        <View style={styles.topButtons}>
          <TouchableOpacity 
            style={styles.topButton}
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.topButtonText}>← Voltar</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.topButton}
            onPress={() => navigation.navigate('Help')}
          >
            <Text style={styles.topButtonText}>Ajuda</Text>
          </TouchableOpacity>
        </View>
      </View>
      
      <Text style={styles.cartTitle}>Meu Carrinho</Text>
      
      {cartItems.length === 0 ? (
        <Text style={styles.emptyCart}>Seu carrinho está vazio.</Text>
      ) : (
        <FlatList
          data={cartItems}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.cartItems}
        />
      )}
      
      {cartItems.length > 0 && (
        <View style={styles.summary}>
          <Text style={styles.totalText}>Total: R$ {calculateTotal().toFixed(2)}</Text>
          <TouchableOpacity 
            style={styles.checkoutButton}
            onPress={() => navigation.navigate('Checkout')}
          >
            <Text style={styles.checkoutButtonText}>Finalizar Pedido</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 15,
    backgroundColor: 'white',
  },
  logo: {
    width: 60,
    height: 60,
    borderRadius: 30,
  },
  headerTitle: {
    fontSize: 24,
    color: '#333',
    flex: 1,
    textAlign: 'center',
  },
  topButtons: {
    flexDirection: 'row',
    gap: 10,
  },
  topButton: {
    backgroundColor: '#323232',
    padding: 10,
    borderRadius: 5,
  },
  topButtonText: {
    color: 'white',
  },
  cartTitle: {
    fontSize: 24,
    textAlign: 'center',
    margin: 20,
    color: '#333',
  },
  cartItems: {
    paddingHorizontal: 20,
  },
  cartItem: {
    flexDirection: 'row',
    backgroundColor: '#f9f9f9',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
  itemImage: {
    width: 60,
    height: 60,
    borderRadius: 5,
  },
  itemDetails: {
    flex: 1,
    marginLeft: 10,
  },
  itemName: {
    fontWeight: 'bold',
  },
  itemPrice: {
    marginVertical: 5,
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 5,
  },
  quantityButton: {
    backgroundColor: '#e0e0e0',
    padding: 5,
    borderRadius: 3,
    width: 30,
    alignItems: 'center',
  },
  quantityButtonText: {
    fontSize: 16,
  },
  quantityText: {
    marginHorizontal: 10,
    fontSize: 16,
  },
  removeButton: {
    backgroundColor: '#ff4d4d',
    padding: 8,
    borderRadius: 5,
    alignSelf: 'flex-start',
  },
  removeButtonText: {
    color: 'white',
  },
  emptyCart: {
    textAlign: 'center',
    marginTop: 50,
    fontSize: 18,
    color: '#666',
  },
  summary: {
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
  },
  totalText: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'right',
    marginBottom: 15,
  },
  checkoutButton: {
    backgroundColor: '#161616',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
  },
  checkoutButtonText: {
    color: 'white',
    fontSize: 18,
  },
});

export default CartScreen;