import React from 'react';
import { View, StyleSheet, ScrollView, Text, TouchableOpacity } from 'react-native';

const Screen = ({ navigation }) => {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.navButton}
          onPress={() => navigation.navigate('Home')}
        >
          <Text style={styles.navButtonText}>Home</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.navButton}
          onPress={() => navigation.navigate('Store')}
        >
          <Text style={styles.navButtonText}>Loja</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.navButton}
          onPress={() => navigation.navigate('Cart')}
        >
          <Text style={styles.navButtonText}>Carrinho</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.navButton}
          onPress={() => navigation.navigate('Register')}
        >
          <Text style={styles.navButtonText}>Cadastrar</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.navButton}
          onPress={() => navigation.navigate('Login')}
        >
          <Text style={styles.navButtonText}>Entrar</Text>
        </TouchableOpacity>
      </View>
      
      <Text style={styles.title}>Central de Ajuda</Text>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Navegação no Site</Text>
        
        <Text style={styles.question}>Como encontrar produtos na loja?</Text>
        <Text style={styles.answer}>
          Na página Loja, você pode usar a barra de pesquisa no topo ou filtrar por categorias no menu lateral. 
          Os produtos mais populares aparecem em destaque na página inicial.
        </Text>
        
        <Text style={styles.question}>Como voltar para a página inicial?</Text>
        <Text style={styles.answer}>
          Clique no link "Home" no menu de navegação superior ou no logo do site no cabeçalho.
        </Text>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Cadastro e Login</Text>
        
        <Text style={styles.question}>Como criar uma conta?</Text>
        <Text style={styles.answer}>
          Acesse a página Cadastrar, preencha o formulário com seus dados e clique em "Criar Conta". 
          Você receberá um e-mail de confirmação.
        </Text>
        
        <Text style={styles.question}>Esqueci minha senha, o que fazer?</Text>
        <Text style={styles.answer}>
          Na página de Entrar, clique em "Esqueci minha senha" e siga as instruções para redefinição. 
          Você receberá um link por e-mail.
        </Text>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Carrinho e Compras</Text>
        
        <Text style={styles.question}>Como adicionar itens ao carrinho?</Text>
        <Text style={styles.answer}>
          Na página do produto, selecione a quantidade desejada e clique no botão "Adicionar ao Carrinho". 
          Você pode ver seus itens a qualquer momento na página do Carrinho.
        </Text>
        
        <Text style={styles.question}>Como remover itens do carrinho?</Text>
        <Text style={styles.answer}>
          Acesse seu Carrinho, localize o item e clique no ícone de lixeira ou no botão "Remover" ao lado do produto.
        </Text>
        
        <Text style={styles.question}>Quais formas de pagamento são aceitas?</Text>
        <Text style={styles.answer}>
          Aceitamos cartões de crédito (Visa, Mastercard, American Express), Pix e boleto bancário. 
          Todas as transações são seguras e criptografadas.
        </Text>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Problemas Técnicos</Text>
        
        <Text style={styles.question}>O site não está carregando corretamente</Text>
        <Text style={styles.answer}>
          1. Atualize a página (F5 ou Ctrl+F5){'\n'}
          2. Limpe o cache do seu navegador{'\n'}
          3. Verifique sua conexão com a internet{'\n'}
          4. Tente acessar por outro navegador (Chrome, Firefox, Edge)
        </Text>
        
        <Text style={styles.question}>Não consigo finalizar minha compra</Text>
        <Text style={styles.answer}>
          Verifique se:{'\n'}
          - Todos os campos obrigatórios estão preenchidos{'\n'}
          - Seu cartão de crédito está válido (data e CVV corretos){'\n'}
          - Você aceitou os termos e condições{'\n'}
          Se o problema persistir, entre em contato conosco.
        </Text>
      </View>
      
      <View style={[styles.section, styles.contactForm]}>
        <Text style={styles.sectionTitle}>Não encontrou o que precisava?</Text>
        <Text style={styles.contactText}>
          Preencha o formulário abaixo e nossa equipe entrará em contato em até 24 horas:
        </Text>
        
        {/* In a real app, you would implement a proper form with state management */}
        <Text style={styles.formLabel}>Nome:</Text>
        <Text style={styles.formInput}>[Campo de Nome]</Text>
        
        <Text style={styles.formLabel}>E-mail:</Text>
        <Text style={styles.formInput}>[Campo de E-mail]</Text>
        
        <Text style={styles.formLabel}>Assunto:</Text>
        <Text style={styles.formInput}>[Seletor de Assunto]</Text>
        
        <Text style={styles.formLabel}>Mensagem:</Text>
        <Text style={styles.formInput}>[Área de Texto]</Text>
        
        <TouchableOpacity style={styles.submitButton}>
          <Text style={styles.submitButtonText}>Enviar Mensagem</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 20,
    backgroundColor: '#f8f9fa',
    padding: 15,
    borderRadius: 5,
  },
  navButton: {
    backgroundColor: '#e9ecef',
    padding: 10,
    borderRadius: 5,
    margin: 5,
  },
  navButtonText: {
    color: '#333',
    fontWeight: 'bold',
  },
  title: {
    fontSize: 24,
    color: '#2c3e50',
    textAlign: 'center',
    marginBottom: 30,
    fontWeight: 'bold',
  },
  section: {
    backgroundColor: '#f8f9fa',
    borderRadius: 8,
    padding: 20,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    color: '#3498db',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    paddingBottom: 10,
    marginBottom: 15,
    fontWeight: 'bold',
  },
  question: {
    fontWeight: 'bold',
    color: '#2c3e50',
    marginTop: 15,
    marginBottom: 5,
  },
  answer: {
    marginBottom: 15,
    color: '#333',
  },
  contactForm: {
    backgroundColor: '#e9f7fe',
  },
  contactText: {
    marginBottom: 15,
  },
  formLabel: {
    fontWeight: 'bold',
    marginBottom: 5,
  },
  formInput: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 4,
    padding: 10,
    marginBottom: 15,
    color: '#666',
  },
  submitButton: {
    backgroundColor: '#3498db',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
  },
  submitButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default Screen;