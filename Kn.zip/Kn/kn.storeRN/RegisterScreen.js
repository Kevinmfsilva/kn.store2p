import React from 'react';
import { View, StyleSheet, TextInput, TouchableOpacity, Text, ImageBackground } from 'react-native';

const RegisterScreen = ({ navigation }) => {
  return (
    <ImageBackground 
      source={require('../assets/car-wash-detailing-station.jpg')} 
      style={styles.background}
    >
      <View style={styles.container}>
        <View style={styles.topButtons}>
          <TouchableOpacity 
            style={styles.topButton}
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.topButtonText}>← Voltar</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.topButton}
            onPress={() => navigation.navigate('Help')}
          >
            <Text style={styles.topButtonText}>Ajuda</Text>
          </TouchableOpacity>
        </View>
        
        <Text style={styles.title}>Cadastro</Text>
        
        <TextInput
          style={styles.input}
          placeholder="Nome de Usuário"
          placeholderTextColor="#999"
        />
        
        <TextInput
          style={styles.input}
          placeholder="Email"
          placeholderTextColor="#999"
          keyboardType="email-address"
        />
        
        <TextInput
          style={styles.input}
          placeholder="Senha"
          placeholderTextColor="#999"
          secureTextEntry
        />
        
        <TouchableOpacity 
          style={styles.button}
          onPress={() => navigation.navigate('Store')}
        >
          <Text style={styles.buttonText}>Seguir</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },
  container: {
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    padding: 30,
    borderRadius: 10,
    width: '90%',
    maxWidth: 350,
    alignSelf: 'center',
  },
  topButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  topButton: {
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    padding: 10,
    borderRadius: 5,
  },
  topButtonText: {
    color: 'white',
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
    textAlign: 'center',
    color: '#333',
  },
  input: {
    width: '100%',
    padding: 12,
    marginVertical: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    textAlign: 'center',
    backgroundColor: 'white',
  },
  button: {
    width: '100%',
    padding: 15,
    marginVertical: 10,
    backgroundColor: '#161616',
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
  },
});

export default RegisterScreen;