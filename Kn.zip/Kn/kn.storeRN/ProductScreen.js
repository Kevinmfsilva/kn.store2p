import React from 'react';
import { View, StyleSheet, Image, Text, TouchableOpacity, ScrollView } from 'react-native';

const ProductScreen = ({ route, navigation }) => {
  const { product } = route.params;

  const addToCart = () => {
    // Implement cart logic here
    navigation.navigate('Cart');
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity 
        style={styles.backButton}
        onPress={() => navigation.goBack()}
      >
        <Text style={styles.backButtonText}>← Voltar</Text>
      </TouchableOpacity>
      
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <Image source={product.image} style={styles.productImage} />
        
        <Text style={styles.productName}>{product.name}</Text>
        <Text style={styles.productPrice}>{product.price}</Text>
        <Text style={styles.productDescription}>
          Descrição Geral
          O AutoClean é um produto de alta performance, com sua exclusiva formulação, substitui com facilidade o uso dos principais produtos na limpeza automotiva.
          
          Pode ser utilizado para limpeza interna do veículo e externa inclusive para uso residência também.
          
          Auto Clean 5L pode ser diluído em até 1000L sendo 1/200 junto ao shampoo em lava car.
          
          Com Auto Clean você economiza dinheiro gastando menos produto e tendo resultados mais rápidos!
        </Text>
        
        <TouchableOpacity 
          style={styles.buyButton}
          onPress={addToCart}
        >
          <Text style={styles.buyButtonText}>Comprar Agora</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  backButton: {
    position: 'absolute',
    top: 20,
    left: 20,
    zIndex: 1,
    backgroundColor: '#313131',
    padding: 10,
    borderRadius: 5,
  },
  backButtonText: {
    color: 'white',
  },
  scrollContainer: {
    padding: 20,
    paddingTop: 60,
    alignItems: 'center',
  },
  productImage: {
    width: '80%',
    height: 200,
    resizeMode: 'contain',
    marginBottom: 20,
  },
  productName: {
    fontSize: 24,
    color: '#333',
    marginBottom: 10,
    textAlign: 'center',
  },
  productPrice: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 10,
  },
  productDescription: {
    fontSize: 16,
    color: '#000',
    marginBottom: 20,
    textAlign: 'center',
  },
  buyButton: {
    width: '100%',
    padding: 15,
    backgroundColor: '#3b3b3b',
    borderRadius: 5,
    alignItems: 'center',
  },
  buyButtonText: {
    color: 'white',
    fontSize: 18,
  },
});

export default ProductScreen;