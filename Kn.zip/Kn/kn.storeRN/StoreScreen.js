import React from 'react';
import { View, StyleSheet, FlatList, TouchableOpacity, Text, ImageBackground, Image } from 'react-native';

const products = [
  { id: '1', name: 'Auto Clean', price: 'R$ 111,80', image: require('../assets/auto_clean_ultra_limpador_5l_magil_clean_777_1_9fcf12146b390c64322510e865fce252.webp') },
  { id: '2', name: 'Shampoo Chantilly', price: 'R$ 129,99', image: require('../assets/images.jfif') },
  // Add all other products here
];

const StoreScreen = ({ navigation }) => {
  const renderProduct = ({ item }) => (
    <TouchableOpacity 
      style={styles.product}
      onPress={() => navigation.navigate('Product', { product: item })}
    >
      <Image source={item.image} style={styles.productImage} />
      <Text style={styles.productName}>{item.name}</Text>
      <Text style={styles.productPrice}>{item.price}</Text>
    </TouchableOpacity>
  );

  return (
    <ImageBackground 
      source={require('../assets/car-wash-detailing-station.jpg')} 
      style={styles.background}
    >
      <View style={styles.header}>
        <Image 
          source={require('../assets/1.png')} 
          style={styles.logo}
        />
        <Text style={styles.headerTitle}>KN.STORE</Text>
        <View style={styles.topButtons}>
          <TouchableOpacity 
            style={styles.topButton}
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.topButtonText}>← Voltar</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.topButton}
            onPress={() => navigation.navigate('Cart')}
          >
            <Text style={styles.topButtonText}>Carrinho</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.topButton}
            onPress={() => navigation.navigate('Help')}
          >
            <Text style={styles.topButtonText}>Ajuda</Text>
          </TouchableOpacity>
        </View>
      </View>
      
      <FlatList
        data={products}
        renderItem={renderProduct}
        keyExtractor={item => item.id}
        numColumns={2}
        contentContainerStyle={styles.productGrid}
      />
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 15,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
  },
  logo: {
    width: 60,
    height: 60,
    borderRadius: 30,
  },
  headerTitle: {
    fontSize: 24,
    color: '#333',
    flex: 1,
    textAlign: 'center',
  },
  topButtons: {
    flexDirection: 'row',
    gap: 10,
  },
  topButton: {
    backgroundColor: '#242424',
    padding: 10,
    borderRadius: 5,
  },
  topButtonText: {
    color: 'white',
  },
  productGrid: {
    padding: 10,
  },
  product: {
    flex: 1,
    margin: 5,
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  productImage: {
    width: 100,
    height: 100,
    borderRadius: 5,
  },
  productName: {
    marginTop: 10,
    fontSize: 16,
    color: '#333',
  },
  productPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
});

export default StoreScreen;